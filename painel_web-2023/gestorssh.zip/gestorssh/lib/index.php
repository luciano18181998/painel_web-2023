<?php header("l\x6f\x63\x61t\x69on: /");
?>